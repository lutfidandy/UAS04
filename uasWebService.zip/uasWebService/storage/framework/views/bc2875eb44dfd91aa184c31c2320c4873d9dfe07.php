<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

    <title>destinations</title>
</head>

<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <table class="table table-borderless">
                            <tr>
                                <th>Destination</th>
                            </tr>
                            <tr>
                                <td><?php echo e($reviews->name); ?></td>
                                <td class="text-center">
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card border-0 shadow rounded">
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <th>Reviews</th>
                            <th>
                            <th><a href="<?php echo e(route('add.review')); ?>" class="btn btn-success">Add review</a></th>
                        </tr>
                        <?php $__currentLoopData = $reviews->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($d->title); ?></td>
                                <td><?php echo e($d->content); ?></td>
                                <td class="text-center">
                                    <form onsubmit="return confirm('are you sure ?');"
                                        action="<?php echo e(route('review.delete', $d->id)); ?>" method="POST">
                                        <a href="<?php echo e(route('review.edit', $d->id)); ?>"
                                            class="btn btn-sm btn-warning">Edit</a>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('show')); ?>" class="btn btn-md btn-secondary">back</a>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\projects\uasWebService\resources\views/show/review.blade.php ENDPATH**/ ?>