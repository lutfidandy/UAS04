<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

    <title>Categories</title>
</head>

<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">



                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <table class="table table-borderless">
                            <tr>
                                <th>Categories</th>
                            </tr>

                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>    
                                    <td><?php echo e($d->category); ?></td>
                                    <td class="text-center">
                                        <form>
                                            <a href="<?php echo e(route('show.destination', $d->id)); ?>"
                                                class="btn btn-sm btn-primary">View destinations</a>
                                            <?php echo csrf_field(); ?>
                                        </form>

                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center text-mute" colspan="4">Data tidak tersedia</td>
                                </tr>
                            <?php endif; ?>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\projects\uasWebService\resources\views/show/index.blade.php ENDPATH**/ ?>