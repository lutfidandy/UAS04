<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

    <title>Add new destination</title>
</head>
<body>
    <div class="card border-0 shadow rounded">
        <div class="card-body">
            <form action="<?php echo e(route('destination.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            
                <div>
                    <label for="name">Name:</label>
                    <input type="text" name="name" id="name" required>
                </div>
            
                <div>
                    <label for="country">Country:</label>
                    <input type="text" name="country" id="country" required>
                </div>
                <div>
                    <label for="price">Price:</label>
                    <input type="text" name="price" id="price" required>
                </div>
                <div>
                    <label for="iternary">Iternary:</label>
                    <input type="text" name="iternary" id="iternary" required>
                </div>
            
                <div>
                    <label for="category">Category:</label>
                    <select name="category_id" id="category" required>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            
                <button type="submit" class="btn btn-md btn-primary">Add</button>
                <a href="<?php echo e(route('show')); ?>" class="btn btn-md btn-secondary">back</a>
            </form>
            
        </div>
    </div>
</body>
<?php /**PATH D:\projects\uasWebService\resources\views/show/newDestination.blade.php ENDPATH**/ ?>