<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

    <title>destinations</title>
</head>

<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <table class="table table-borderless">
                            <tr>
                                <th>Category</th>
                            </tr>
                            <tr>
                                <td><?php echo e($data->category); ?></td>
                                <td class="text-center">
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card border-0 shadow rounded">
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <th>Destinations</th>
                            <th><a href="<?php echo e(route('add.destination')); ?>" class="btn btn-success">Add new destination</a>
                            </th>
                        </tr>
                        <?php $__currentLoopData = $data->destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($destination->name); ?></td>
                                <td><?php echo e($destination->country); ?></td>
                                <td><?php echo e($destination->price); ?></td>
                                <td><?php echo e($destination->iternary); ?></td>
                                <td class="text-center">
                                    <form>
                                        <a href="<?php echo e(route('show.review', $destination->id)); ?>"
                                            class="btn btn-sm btn-primary">reviews</a>
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>
                    <a href="<?php echo e(route('show')); ?>" class="btn btn-md btn-secondary">back</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\projects\uasWebService\resources\views/show/destination.blade.php ENDPATH**/ ?>