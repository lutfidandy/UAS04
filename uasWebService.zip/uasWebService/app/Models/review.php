<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class review extends Model
{
    use HasFactory;
    protected $fillable = [
        'destination_id',
        'title',
        'content',
        // Add more fillable columns as needed
    ];

    public function destination()
    {
        return $this->belongsTo(Destination::class);
    }
}
