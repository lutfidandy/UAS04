<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

    <title>Categories</title>
</head>

<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">



                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <table class="table table-borderless">
                            <tr>
                                <th>Categories</th>
                            </tr>

                            @forelse ($data as $d)
                                <tr>    
                                    <td>{{ $d->category }}</td>
                                    <td class="text-center">
                                        <form>
                                            <a href="{{ route('show.destination', $d->id) }}"
                                                class="btn btn-sm btn-primary">View destinations</a>
                                            @csrf
                                        </form>

                                    </td>
                                </tr>

                            @empty
                                <tr>
                                    <td class="text-center text-mute" colspan="4">Data tidak tersedia</td>
                                </tr>
                            @endforelse

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
