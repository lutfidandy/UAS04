<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

    <title>destinations</title>
</head>

<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <table class="table table-borderless">
                            <tr>
                                <th>Category</th>
                            </tr>
                            <tr>
                                <td>{{ $data->category }}</td>
                                <td class="text-center">
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card border-0 shadow rounded">
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <th>Destinations</th>
                            <th><a href="{{ route('add.destination')}}" class="btn btn-success">Add new destination</a>
                            </th>
                        </tr>
                        @foreach ($data->destinations as $destination)
                            <tr>
                                <td>{{ $destination->name }}</td>
                                <td>{{ $destination->country }}</td>
                                <td>{{ $destination->price }}</td>
                                <td>{{ $destination->iternary }}</td>
                                <td class="text-center">
                                    <form>
                                        <a href="{{ route('show.review', $destination->id) }}"
                                            class="btn btn-sm btn-primary">reviews</a>
                                        @csrf
                                    </form>
                                </td>
                            </tr>
                        @endforeach

                    </table>
                    <a href="{{ route('show') }}" class="btn btn-md btn-secondary">back</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
