<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

    <title>Add new destination</title>
</head>
<body>
    <div class="card border-0 shadow rounded">
        <div class="card-body">
            <form action="{{ route('destination.store') }}" method="POST">
                @csrf
            
                <div>
                    <label for="name">Name:</label>
                    <input type="text" name="name" id="name" required>
                </div>
            
                <div>
                    <label for="country">Country:</label>
                    <input type="text" name="country" id="country" required>
                </div>
                <div>
                    <label for="price">Price:</label>
                    <input type="text" name="price" id="price" required>
                </div>
                <div>
                    <label for="iternary">Iternary:</label>
                    <input type="text" name="iternary" id="iternary" required>
                </div>
            
                <div>
                    <label for="category">Category:</label>
                    <select name="category_id" id="category" required>
                        @foreach ($categories as $category)
                            <option value="{{ $category->id }}">{{ $category->category }}</option>
                        @endforeach
                    </select>
                </div>
            
                <button type="submit" class="btn btn-md btn-primary">Add</button>
                <a href="{{ route('show') }}" class="btn btn-md btn-secondary">back</a>
            </form>
            
        </div>
    </div>
</body>
