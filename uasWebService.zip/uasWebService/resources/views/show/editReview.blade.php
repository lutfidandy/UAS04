<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

    <title>Edit review</title>
</head>
<body>
    <div class="card border-0 shadow rounded">
        <div class="card-body">
            <form action="{{ route('review.update', $reviews->id) }}" method="POST">
                @csrf
                <div>
                    <label for="title">title:</label>
                    <input type="text" name="title" id="title" required value="{{ old('title', $reviews->title) }}">
                </div>
            <br>
                <div>
                    <label for="content">content:</label>
                    <input type="text" name="content" id="content" required style="width: 300px; height: 200px;" required value="{{ old('content', $reviews->content) }}" >
                </div>
            
                <button type="submit" class="btn btn-md btn-primary">Add</button>
                <a href="{{ route('show') }}" class="btn btn-md btn-secondary">back</a>
            </form>
            
        </div>
    </div>
</body>
