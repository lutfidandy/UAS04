<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

    <title>destinations</title>
</head>

<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <table class="table table-borderless">
                            <tr>
                                <th>Destination</th>
                            </tr>
                            <tr>
                                <td>{{ $reviews->name }}</td>
                                <td class="text-center">
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card border-0 shadow rounded">
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <th>Reviews</th>
                            <th>
                            <th><a href="{{ route('add.review') }}" class="btn btn-success">Add review</a></th>
                        </tr>
                        @foreach ($reviews->reviews as $d)
                            <tr>
                                <td>{{ $d->title }}</td>
                                <td>{{ $d->content }}</td>
                                <td class="text-center">
                                    <form onsubmit="return confirm('are you sure ?');"
                                        action="{{ route('review.delete', $d->id) }}" method="POST">
                                        <a href="{{ route('review.edit', $d->id) }}"
                                            class="btn btn-sm btn-warning">Edit</a>
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>

                                </td>
                            </tr>
                        @endforeach
                        <a href="{{ route('show') }}" class="btn btn-md btn-secondary">back</a>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
