<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\categoryController;
use App\Http\Controllers\destinationController;
use App\Http\Controllers\reviewController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/home', function(){
    return view('welcome');
});


Route::get('/', [categoryController::class,'index'])->name('show');
Route::get('/show/{id}/destination', [categoryController::class,'show'])->name('show.destination');
Route::get('/show/{id}/review', [reviewController::class,'show'])->name('show.review');

Route::get('/show/newDestination', [destinationController::class,'create'])->name('add.destination');
Route::post('/show/destination/store', [destinationController::class,'store'])->name('destination.store');

Route::get('/show/newReview', [reviewController::class,'create'])->name('add.review');
Route::post('/show/review/store', [reviewController::class,'store'])->name('review.store');

Route::delete('/show/{id}/delete', [reviewController::class,'destroy'])->name('review.delete');
Route::get('/show/{id}/edit', [reviewController::class,'edit'])->name('review.edit');
Route::post('/show/{id}/updateReview', [reviewController::class,'update'])->name('review.update');
