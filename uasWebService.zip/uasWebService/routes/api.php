<?php


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\categoryController;
use App\Http\Controllers\API\destinationController;
use App\Http\Controllers\API\reviewController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::group(['prefix' => 'v1'], function () {

    Route::get('destinations', [destinationController::class, 'index']);
    Route::get('destinations/{id}', [destinationController::class, 'show']);
    Route::post('destinations', [destinationController::class, 'store']);
    Route::patch('destinations/{id}', [destinationController::class, 'update']);
    Route::delete('destinations/{id}', [destinationController::class, 'delete']);

    Route::resource('categories', categoryController::class);
    Route::resource('reviews', reviewController::class);

});

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
